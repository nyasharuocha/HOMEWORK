package REST;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;


@WebServlet(name = "ServletBook")
public class ServletBook extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private HttpClient client = HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1).build();
    private String base_url = "https://anypoint.mulesoft.com/mocking/api/v1/links/d2d1d103-4916-4b10-869a-235555055072";

    public void init(ServletConfig config)
            throws ServletException {
        super.init (config);
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException,

            java.io.IOException {response.setContentType("text/html");

        String AuthorID,AuthorName, DOB, AGE;

        java.io.PrintWriter out = response.getWriter();

        AuthorID = request.getParameter("authorid");
        AuthorName = request.getParameter("authorname");
        DOB = request.getParameter("dob");
        AGE = request.getParameter("age");


        if(AuthorID.isEmpty() && AuthorName.isEmpty()&& DOB.isEmpty()&& AGE.isEmpty()) {
            out.println("<html><head><title> Tutorial Demo Welcome</title></head>");
            out.println("<body><h3>PLEASE ENTER AUTHOR DETAILS!</h3></body></html>");
        }
        else
        {   out.print("<html>");
            out.print("<body>");
            out.print("<center>");
            out.print("<h1>ADD AUTHORS</h1>");
            out.print("<p> AuthorID : " + AuthorID + "</p>");
            out.print("<p> AuthorName : " + AuthorName + "</p>");
            out.print("<p> DOB : " + DOB + "</p>");
            out.print("<p> AGE : " + AGE + "</p>");
            out.print("</center>");
            out.print("</body>");
            out.print("</html>");

            // Generate Body String
            String json = new StringBuilder().append("{").append("\"AuthorID\":\"1\",")
                    .append("\"AuthorName\":\"Nyaradzo\",").append("\"DOB\":\"02/04/1991\",")
                    .append("\"AGE\":\"28\" ,").append("}").toString();
            //Create Http Request
            HttpRequest requests = HttpRequest.newBuilder().POST(HttpRequest.BodyPublishers.ofString(json))
                    .uri(URI.create(base_url + "/author")).setHeader("Accept", "application/json")
                    .setHeader("Content-Type", "application/json").build();
            // Capture Response
            HttpResponse<String> responsesOutput = null;
            try {
                responsesOutput = client.send(requests, HttpResponse.BodyHandlers.ofString());
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }

    }



    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, java.io.IOException
    {processRequest(request, response);}

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            URL url = new URL(
                    "https://anypoint.mulesoft.com/mocking/api/v1/links/bc8c9696-9f99-446d-968f-5f9fb5b61d9f/users/authors");

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : " +
                        conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);
            String output;
            while ((output = br.readLine()) != null) {
                PrintWriter out = response.getWriter();
                out.println("<h1>" + " Author Records " + "</h1>");
                out.println("<h3>" + output + "</h3>");
            }
            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }


    }

    public void destroy(){

    }

}
