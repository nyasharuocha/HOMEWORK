package com.example.demo.dao;

import com.example.demo.entity.Author;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
@Repository
public class AuthorDao {
    private static Map<Integer, Author> authors;
    static {
        authors = new HashMap<Integer, Author>() {
            {
                put(1, new Author(1, "Nyasha", "1998/11/11", 21));
                put(3, new Author(3, "Nyarai", "11 / 11 / 1997", 22));
                put(5, new Author(5, "Nyaradzo", "11 / 11 / 1996", 23));

            }

        };
    }

        public Collection<Author> getAllAuthors(){
            return this.authors.values();
        }
       public Author getAuthorById(int id){
        return this.authors.get(id);
       }
       public void removeAuthorById(int id){
        this.authors.remove(id);
       }
       public void updateAuthor(Author author){
        Author a = authors.get(author.getId());
        a.setName(author.getName());
        a.setId(author.getId());
        a.setDob(author.getDob());
        a.setAge(author.getAge());
        authors.put(author.getId(), author);

           }
           public void insertAuthorToDb(Author author){
        this.authors.put(author.getId(), author);
           }
       }


