package com.example.demo.controller;

import com.example.demo.entity.Author;
import com.example.demo.service.AuthorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;

@RestController
@RequestMapping("/authors")
public class AuthorController {
    @Autowired
    private AuthorService authorService;
    @RequestMapping(method = RequestMethod.GET)
    public Collection<Author> getAllAuthors(){ return authorService.getAllAuthors(); }

   @RequestMapping(value = "/{id}", method = RequestMethod.GET)
   public Author getAuthorById(@PathVariable("id") int id){ return authorService.getAuthorById(id); }

   @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
   public void deleteAuthorById(@PathVariable("id") int id){
       authorService.removeAuthorById(id);
   }

   @RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
   public void deleteAuthorById(@RequestBody Author author){
    authorService.updateAuthor(author);
   }
    @RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    public void insertAuthor(@RequestBody Author author){
       authorService.insertAuthor(author);
    }
}


