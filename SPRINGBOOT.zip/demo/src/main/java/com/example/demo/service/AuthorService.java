package com.example.demo.service;

import com.example.demo.dao.AuthorDao;
import com.example.demo.entity.Author;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
public class AuthorService {
    @Autowired
//    @Qualifier("mongoData")
    private AuthorDao authorDao;
    public Collection<Author> getAllAuthors(){return this.authorDao.getAllAuthors();}
    public Author getAuthorById(int id){ return this.authorDao.getAuthorById(id); }
    public void removeAuthorById(int id) { this.authorDao.removeAuthorById(id); }
    public void updateAuthor(Author author){ this.authorDao.updateAuthor(author); }
    public void insertAuthor(Author author) { this.authorDao.insertAuthorToDb(author); }
}


